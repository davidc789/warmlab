import warm

def test_answer():
    print(list(warm.ring_2d_layout(4)))
    assert True
